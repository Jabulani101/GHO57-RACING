import React from 'react';
import RacingEngine from './components/RacingEngine';

export default function App() {
  return <RacingEngine />;
}